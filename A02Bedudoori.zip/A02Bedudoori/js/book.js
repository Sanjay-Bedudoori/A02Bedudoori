function calculateFare() {
	var sel1 = document.getElementById("sel1").value;
	var sel2 = document.getElementById("sel2").value;


	if( sel1 == "Maryville" && sel2 == "Kansas" || sel1 == "Kansas" && sel2 == "Maryville" ){
		var distance = 96;
		document.getElementById("distance").value = distance;
		
	}
	else if(sel1 == "Maryville" && sel2 == "St Joseph" || sel1 == "St Joseph" && sel2 == "Maryville"){
		var distance = 43;
		document.getElementById("distance").value = distance;
	
	}
	else if(sel1 == "St Joseph" && sel2 == "Kansas" || sel1 == "Kansas" && sel2 == "St Joseph") {
		var distance = 55;
		document.getElementById("distance").value = distance;
	
	}
	else if(sel1==sel2){
		alert("origin and destination cannot be the same");
		
	}

	
	var passengers = document.getElementById("passengers").value;
	if(passengers <= 4 && passengers >0){
		var passengers = document.getElementById("passengers").value;
	}
	else{
		alert("Maximum seats should be only 4");
	}
	
	var time = document.getElementById("time").value;

	var tip = document.querySelector('input[name="tip"]:checked').value;
	
	var total = calculate(distance,passengers,tip);

	total = total.toFixed(2);
	document.getElementById("from").innerHTML = "PickUp Location : "+sel1;
	document.getElementById("to").innerHTML = "Destination location : "+sel2;
	document.getElementById("date").innerHTML = "Booking Date : "+time;
	document.getElementById("num").innerHTML = "No of Passengers : "+passengers;
	document.getElementById("fare").innerHTML = "Estimated Fare : "+total;


}

function calculate(distance,passengers,tip){
	if(typeof distance == 'number' || typeof passengers == 'number' || typeof trip == 'number' || distance>0 || passengers >0 || trip >0)
		return distance*0.4*passengers + distance*0.4*passengers*tip/100 ;
	
	else
		throw Error("Enter only positive numeric value");
	
}

$(document).ready(function() {
		$(".flip").click(function() {
			$(".panel").slideToggle("slow");
		});
	});

$(function() {
    $('.panel')
        .hide();
});