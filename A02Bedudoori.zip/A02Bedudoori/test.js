



QUnit.test('Testing calculate function with many inputs', function (assert) {
    assert.equal(calculate(1, 2,3), 6, 'Tested with three relatively small positive numbers');
    assert.equal(calculate(-1, -2,-3), , 'Tested with two negative numbers. Any arguments less than 1 will be set to 1.');
    
    assert.throws(function () { calculate(-1,-2,-3); }, new Error ("Enter only positive numeric value"), 'raises an error');/The given argument is not a number/, 'Passing in a string correctly raises an Error');
});

